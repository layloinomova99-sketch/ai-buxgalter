import React, { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useCompany } from "@/context/CompanyContext";
import { useAuth } from "@/context/AuthContext";
import { ShieldCheck } from "lucide-react";

// Texnik amal kalitlari -> o'zbekcha
const WHAT_UZ = {
  user_registered: "Ro'yxatdan o'tdi",
  user_login: "Tizimga kirdi",
  password_changed: "Parolni o'zgartirdi",
  user_access_updated: "Foydalanuvchi ruxsati o'zgartirildi",
  company_created: "Kompaniya yaratildi",
  company_updated: "Kompaniya ma'lumotlari o'zgartirildi",
  company_deleted: "Kompaniya o'chirildi",
  receipt_created: "Chek qo'shildi",
  mapping_created: "Mapping yaratildi",
  mapping_deleted: "Mapping o'chirildi",
  rule_created: "Qoida qo'shildi",
  rule_updated: "Qoida tahrirlandi",
  rule_deleted: "Qoida o'chirildi",
  one_c_connection_saved: "1C ulanishi saqlandi",
};

const FIELD_UZ = {
  base_url: "1C manzil", name: "Nomi", email: "Email", soliq: "Soliq", one_c: "1C",
  category: "Kategoriya", instruction: "Qoida", priority: "Ustuvorlik", version: "Versiya",
  receipt_id: "Chek", active: "Faol", access_granted: "Access", role: "Rol", payment_status: "To'lov",
  ok: "Natija", ref_key: "1C Ref", imported: "Yozildi", failed: "Xatolar",
};

const fmtTime = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  return d.toLocaleString("ru-RU", { timeZone: "Asia/Tashkent", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
};

const fmtVal = (v) => {
  if (v === true) return "ha";
  if (v === false) return "yo'q";
  if (v === null || v === undefined) return "—";
  if (typeof v === "object") return Array.isArray(v) ? `${v.length} ta` : JSON.stringify(v);
  return String(v);
};

function Details({ value }) {
  if (!value || typeof value !== "object") return <span>—</span>;
  const entries = Object.entries(value).filter(([k]) => k !== "updated_at");
  if (!entries.length) return <span>—</span>;
  return (
    <div className="space-y-0.5">
      {entries.slice(0, 6).map(([k, v]) => (
        <div key={k} className="truncate" title={fmtVal(v)}>
          <span className="text-foreground/70">{FIELD_UZ[k] || k}:</span> {fmtVal(v)}
        </div>
      ))}
    </div>
  );
}

export default function Audit() {
  const { active } = useCompany();
  const { user } = useAuth();
  const [rows, setRows] = useState([]);

  useEffect(() => {
    const params = {};
    if (active) params.company_id = active.id;
    if (!active && user?.role !== "creator") return;
    api.get("/audit", { params }).then((r) => setRows(r.data.audit_logs || []));
  }, [active, user]);

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold tracking-tight">Audit loglari</h1>
        <p className="text-sm text-muted-foreground mt-1">Barcha muhim harakatlar yozib boriladi · vaqt Toshkent bo'yicha</p>
      </div>
      {rows.length === 0 ? (
        <div className="border-2 border-dashed rounded-sm p-12 text-center">
          <ShieldCheck className="h-10 w-10 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Loglar bo'sh</p>
        </div>
      ) : (
        <div className="border rounded-sm overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase tracking-widest">
              <tr>
                <th className="text-left px-4 py-3 whitespace-nowrap">Vaqt</th>
                <th className="text-left px-4 py-3">Kim</th>
                <th className="text-left px-4 py-3">Nima</th>
                <th className="text-left px-4 py-3">Manba</th>
                <th className="text-left px-4 py-3">Ma'lumot</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a) => (
                <tr key={a.id} className="border-t hover:bg-muted/30 align-top" data-testid={`audit-row-${a.id}`}>
                  <td className="px-4 py-3 font-mono text-xs whitespace-nowrap">{fmtTime(a.when)}</td>
                  <td className="px-4 py-3 text-xs" title={a.who}>{a.who_name || (a.who ? `${a.who.slice(0, 8)}…` : "—")}</td>
                  <td className="px-4 py-3">{WHAT_UZ[a.what] || a.what}</td>
                  <td className="px-4 py-3 text-xs">{a.source === "telegram" ? "Telegram" : a.source === "web" ? "Veb" : a.source}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground max-w-md"><Details value={a.new_value} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
