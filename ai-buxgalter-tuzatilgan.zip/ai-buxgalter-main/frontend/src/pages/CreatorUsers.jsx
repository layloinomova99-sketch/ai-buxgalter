import React, { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

// Avtotestlar yaratgan akkauntlar (example.com, test.uz, test_ / user_ prefiksli)
const isTestAccount = (u) =>
  /@(example\.com|test\.uz|test\.com)$/i.test(u.email || "") ||
  /^(test|user_|reg_|co_|slash)/i.test(u.email || "");

const ROLE_UZ = { creator: "Creator", administrator: "Administrator", observer: "Observer" };

export default function CreatorUsers() {
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState("");
  const [role, setRole] = useState("all");
  const [hideTests, setHideTests] = useState(true);

  const load = () => api.get("/creator/users").then((r) => setRows(r.data.users || []));
  useEffect(() => { load(); }, []);

  const toggle = async (id, field, value) => {
    try {
      await api.patch(`/creator/users/${id}`, { [field]: value });
      toast.success("Yangilandi"); load();
    } catch (e) { toast.error(e?.response?.data?.detail || "Xatolik"); }
  };

  const testCount = useMemo(() => rows.filter(isTestAccount).length, [rows]);
  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    return rows.filter((u) =>
      (!hideTests || !isTestAccount(u)) &&
      (role === "all" || u.role === role) &&
      (!s || `${u.full_name || ""} ${u.email || ""} ${u.phone || ""}`.toLowerCase().includes(s)));
  }, [rows, q, role, hideTests]);

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-bold tracking-tight">Foydalanuvchilar</h1>
        <p className="text-sm text-muted-foreground mt-1">Access berish/olib qo'yish. Parollar hech qachon ko'rinmaydi.</p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ism, email yoki telefon bo'yicha qidirish..."
          className="max-w-xs" data-testid="users-search" />
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="w-44" data-testid="users-role-filter"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Barcha rollar</SelectItem>
            <SelectItem value="creator">Creator</SelectItem>
            <SelectItem value="administrator">Administrator</SelectItem>
            <SelectItem value="observer">Observer</SelectItem>
          </SelectContent>
        </Select>
        <label className="flex items-center gap-2 text-sm">
          <Switch checked={hideTests} onCheckedChange={setHideTests} data-testid="users-hide-tests" />
          Test akkauntlarni yashirish ({testCount})
        </label>
        <span className="text-xs text-muted-foreground ml-auto">{shown.length} / {rows.length} ta</span>
      </div>

      <div className="border rounded-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-widest">
            <tr>
              <th className="text-left px-4 py-3">Ism</th>
              <th className="text-left px-4 py-3">Email</th>
              <th className="text-left px-4 py-3">Rol</th>
              <th className="text-left px-4 py-3">Kompaniyalar</th>
              <th className="text-left px-4 py-3">Faol</th>
              <th className="text-left px-4 py-3">Access</th>
              <th className="text-left px-4 py-3">To'lov</th>
            </tr>
          </thead>
          <tbody>
            {shown.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">Hech kim topilmadi</td></tr>
            )}
            {shown.map((u) => (
              <tr key={u.id} className="border-t" data-testid={`user-row-${u.id}`}>
                <td className="px-4 py-3 font-medium">{u.full_name}</td>
                <td className="px-4 py-3 font-mono text-xs">{u.email}</td>
                <td className="px-4 py-3"><Badge variant="outline" className="rounded-sm">{ROLE_UZ[u.role] || u.role}</Badge></td>
                <td className="px-4 py-3">{u.companies_count}</td>
                <td className="px-4 py-3">
                  <Switch checked={!!u.active} disabled={u.role === "creator"} onCheckedChange={(v) => toggle(u.id, "active", v)}
                    data-testid={`toggle-active-${u.id}`} />
                </td>
                <td className="px-4 py-3">
                  <Switch checked={!!u.access_granted} disabled={u.role === "creator"} onCheckedChange={(v) => toggle(u.id, "access_granted", v)}
                    data-testid={`toggle-access-${u.id}`} />
                </td>
                <td className="px-4 py-3">
                  <Badge variant="outline" className="rounded-sm">{u.payment_status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
