import React, { useState } from "react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { KeyRound, Loader2 } from "lucide-react";
import { toast } from "sonner";

export function ChangePasswordDialog() {
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ old: "", nw: "", rep: "" });
  const [busy, setBusy] = useState(false);

  const save = async () => {
    if (f.nw.length < 10) return toast.error("Yangi parol kamida 10 belgi bo'lsin");
    if (f.nw !== f.rep) return toast.error("Yangi parollar mos emas");
    setBusy(true);
    try {
      await api.post("/auth/change-password", { old_password: f.old, new_password: f.nw });
      toast.success("Parol o'zgartirildi");
      setOpen(false); setF({ old: "", nw: "", rep: "" });
    } catch (e) { toast.error(e?.response?.data?.detail || "Xatolik"); }
    finally { setBusy(false); }
  };

  return (
    <>
      <Button variant="ghost" size="icon" title="Parolni o'zgartirish" onClick={() => setOpen(true)} data-testid="change-password-btn">
        <KeyRound className="h-4 w-4" />
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-background max-w-sm">
          <DialogHeader><DialogTitle>Parolni o'zgartirish</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Joriy parol</Label><Input type="password" value={f.old} onChange={(e) => setF({ ...f, old: e.target.value })} /></div>
            <div><Label>Yangi parol (kamida 10 belgi)</Label><Input type="password" value={f.nw} onChange={(e) => setF({ ...f, nw: e.target.value })} /></div>
            <div><Label>Yangi parolni takrorlang</Label><Input type="password" value={f.rep} onChange={(e) => setF({ ...f, rep: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Bekor qilish</Button>
            <Button onClick={save} disabled={busy || !f.old || !f.nw} className="bg-emerald-600 hover:bg-emerald-700">
              {busy && <Loader2 className="h-4 w-4 animate-spin mr-2" />} Saqlash
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
