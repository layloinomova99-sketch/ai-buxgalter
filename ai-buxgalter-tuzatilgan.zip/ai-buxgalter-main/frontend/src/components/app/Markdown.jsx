import React from "react";

// Yengil, xavfsiz Markdown renderer (qo'shimcha kutubxonasiz, HTML inject qilinmaydi).
// Qo'llab-quvvatlaydi: # sarlavhalar, **qalin**, *kursiv*, `kod`, ```kod bloki```,
// - / 1. ro'yxatlar, > iqtibos, --- chiziq, | jadval |.

function inline(text, keyBase = "i") {
  const out = [];
  const re = /(\*\*([^*]+)\*\*|`([^`]+)`|\*([^*\s][^*]*)\*|_([^_\s][^_]*)_)/g;
  let last = 0, m, k = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    if (m[2] !== undefined) out.push(<strong key={`${keyBase}-${k++}`}>{m[2]}</strong>);
    else if (m[3] !== undefined) out.push(<code key={`${keyBase}-${k++}`} className="px-1 py-0.5 rounded bg-background/70 font-mono text-[0.85em]">{m[3]}</code>);
    else out.push(<em key={`${keyBase}-${k++}`}>{m[4] ?? m[5]}</em>);
    last = re.lastIndex;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

const isTableRow = (l) => /^\s*\|.*\|\s*$/.test(l);
const isSep = (l) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l);
const cells = (l) => l.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((c) => c.trim());

export function Markdown({ text }) {
  if (!text) return null;
  const lines = String(text).replace(/\r\n/g, "\n").split("\n");
  const blocks = [];
  let i = 0, k = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (/^\s*```/.test(line)) {
      const buf = []; i++;
      while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      blocks.push(<pre key={k++} className="bg-background/70 rounded-sm p-3 overflow-x-auto text-xs font-mono">{buf.join("\n")}</pre>);
      continue;
    }
    if (!line.trim()) { i++; continue; }
    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) { blocks.push(<hr key={k++} className="my-2 border-border" />); i++; continue; }

    const h = line.match(/^\s*(#{1,4})\s+(.*)$/);
    if (h) {
      const size = ["text-lg", "text-base", "text-sm", "text-sm"][h[1].length - 1];
      blocks.push(<div key={k++} className={`${size} font-semibold mt-2`}>{inline(h[2], `h${k}`)}</div>);
      i++; continue;
    }

    if (isTableRow(line) && i + 1 < lines.length && isSep(lines[i + 1])) {
      const head = cells(line); i += 2;
      const body = [];
      while (i < lines.length && isTableRow(lines[i])) body.push(cells(lines[i++]));
      blocks.push(
        <div key={k++} className="overflow-x-auto">
          <table className="text-xs border-collapse my-1">
            <thead><tr>{head.map((c, j) => <th key={j} className="border px-2 py-1 text-left font-semibold bg-background/60">{inline(c, `th${k}${j}`)}</th>)}</tr></thead>
            <tbody>{body.map((r, ri) => <tr key={ri}>{r.map((c, j) => <td key={j} className="border px-2 py-1 align-top">{inline(c, `td${k}${ri}${j}`)}</td>)}</tr>)}</tbody>
          </table>
        </div>
      );
      continue;
    }

    if (/^\s*>/.test(line)) {
      const buf = [];
      while (i < lines.length && /^\s*>/.test(lines[i])) buf.push(lines[i++].replace(/^\s*>\s?/, ""));
      blocks.push(<blockquote key={k++} className="border-l-2 border-amber-500 pl-3 italic">{inline(buf.join(" "), `q${k}`)}</blockquote>);
      continue;
    }

    if (/^\s*([-*•]|\d+[.)])\s+/.test(line)) {
      const ordered = /^\s*\d+[.)]/.test(line);
      const items = [];
      while (i < lines.length && /^\s*([-*•]|\d+[.)])\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*([-*•]|\d+[.)])\s+/, ""));
      const Tag = ordered ? "ol" : "ul";
      blocks.push(
        <Tag key={k++} className={`${ordered ? "list-decimal" : "list-disc"} pl-5 space-y-0.5`}>
          {items.map((t, j) => <li key={j}>{inline(t, `l${k}${j}`)}</li>)}
        </Tag>
      );
      continue;
    }

    const buf = [];
    while (i < lines.length && lines[i].trim() && !/^\s*(```|#{1,4}\s|>|[-*•]\s|\d+[.)]\s|-{3,}\s*$)/.test(lines[i]) && !isTableRow(lines[i])) buf.push(lines[i++]);
    if (!buf.length) buf.push(lines[i++]);
    blocks.push(<p key={k++}>{buf.map((b, j) => <React.Fragment key={j}>{j > 0 && <br />}{inline(b, `p${k}${j}`)}</React.Fragment>)}</p>);
  }
  return <div className="space-y-2 text-left">{blocks}</div>;
}
